sap.ui.define(["com/flexso/test/controller/BaseController"], function (Controller) {
    "use strict";

    return Controller.extend("com.flexso.test.controller.MainView", {});
});
